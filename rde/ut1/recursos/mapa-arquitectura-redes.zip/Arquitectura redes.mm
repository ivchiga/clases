<map version="0.9.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="Arquitectura redes" ID="ID_409004466" CREATED="1381261040606" MODIFIED="1381262656626" COLOR="#000000">
<font SIZE="20"/>
<hook NAME="MapStyle" max_node_width="600"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node TEXT="aspectos a tener en cuenta" POSITION="right" ID="ID_1070184300" CREATED="1381261275861" MODIFIED="1381264392481" COLOR="#0033ff">
<font SIZE="18"/>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<cloud COLOR="#ccc2c2" WIDTH="0"/>
<node TEXT="comunicaci&#xf3;n por red implica aspectos diversos" ID="ID_701899246" CREATED="1381261074612" MODIFIED="1381262930291" HGAP="24" VSHIFT="-14" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="par&#xe1;metros el&#xe9;ctricos de" ID="ID_1671995955" CREATED="1381261112075" MODIFIED="1381262665075" COLOR="#990000">
<font SIZE="14"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="cables" ID="ID_1480595505" CREATED="1381261146191" MODIFIED="1381262665076" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="conectores" ID="ID_1722953720" CREATED="1381261149212" MODIFIED="1381262665077" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="se&#xf1;ales" ID="ID_76296421" CREATED="1381261152980" MODIFIED="1381262665078" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="dispositivos" ID="ID_1142852696" CREATED="1381261162052" MODIFIED="1381262665078" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT=".." ID="ID_82090445" CREATED="1381261167922" MODIFIED="1381262665079" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="forma de agrupar informaci&#xf3;n" ID="ID_65853801" CREATED="1381261179516" MODIFIED="1381262665080" COLOR="#990000">
<font SIZE="14"/>
<edge STYLE="bezier" WIDTH="thin"/>
</node>
<node TEXT="correcci&#xf3;n de errores" ID="ID_1065474712" CREATED="1381261191876" MODIFIED="1381262665081" COLOR="#990000">
<font SIZE="14"/>
<edge STYLE="bezier" WIDTH="thin"/>
</node>
<node TEXT="compartici&#xf3;n de medio &#xfa;nico" ID="ID_1781211255" CREATED="1381261203524" MODIFIED="1381262665082" COLOR="#990000">
<font SIZE="14"/>
<edge STYLE="bezier" WIDTH="thin"/>
</node>
<node TEXT="distinguir equipos de la red entre s&#xed;" ID="ID_1254897963" CREATED="1381261219117" MODIFIED="1381262665083" COLOR="#990000">
<font SIZE="14"/>
<edge STYLE="bezier" WIDTH="thin"/>
</node>
<node TEXT="tipo de informaci&#xf3;n a transmitir" ID="ID_1282615732" CREATED="1381261229557" MODIFIED="1381262665084" COLOR="#990000">
<font SIZE="14"/>
<edge STYLE="bezier" WIDTH="thin"/>
</node>
<node TEXT="etc..." ID="ID_745473108" CREATED="1381261242573" MODIFIED="1381262665085" COLOR="#990000">
<font SIZE="14"/>
<edge STYLE="bezier" WIDTH="thin"/>
</node>
</node>
<node TEXT="complejo abordar de forma global" ID="ID_1925591507" CREATED="1381262697195" MODIFIED="1381262717435" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
</node>
<node TEXT="Existencia de redes heterogeneas" ID="ID_1130430966" CREATED="1381262732277" MODIFIED="1381262793263" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="diferentes" ID="ID_1676660056" CREATED="1381262793265" MODIFIED="1381262801311" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="fabricantes" ID="ID_1244298535" CREATED="1381262801313" MODIFIED="1381262810211" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="hardware" ID="ID_807064151" CREATED="1381262810909" MODIFIED="1381262815467" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="software" ID="ID_1006396668" CREATED="1381262815893" MODIFIED="1381262821171" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="algunas incompatibles entre s&#xed;" ID="ID_725065112" CREATED="1381262828045" MODIFIED="1381262839075" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
</node>
<node TEXT="Caracter&#xed;sticas generales" POSITION="right" ID="ID_463030988" CREATED="1381262938182" MODIFIED="1381264408074" COLOR="#0033ff">
<font SIZE="18"/>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<cloud WIDTH="0"/>
<node TEXT="dependen de la tecnolog&#xed;a utilizada" ID="ID_756611060" CREATED="1381262957013" MODIFIED="1381262973544" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
</node>
<node TEXT="son" ID="ID_1167531507" CREATED="1381262974752" MODIFIED="1381262977864" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="topolog&#xed;a" ID="ID_1459711352" CREATED="1381262977867" MODIFIED="1381262982173" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="forma de organizaci&#xf3;n de su cableado" ID="ID_1358901278" CREATED="1381263006743" MODIFIED="1381263020153" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="define" ID="ID_700395658" CREATED="1381263033679" MODIFIED="1381263044089" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="como se interconectan" ID="ID_1133158672" CREATED="1381263044091" MODIFIED="1381263060586" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="equipos" ID="ID_72730875" CREATED="1381263060589" MODIFIED="1381263063613" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="dispositivos" ID="ID_964293496" CREATED="1381263064488" MODIFIED="1381263068309" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="camino de la transmisi&#xf3;n" ID="ID_1500249140" CREATED="1381263076768" MODIFIED="1381263110390" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node ID="ID_1279203775" CREATED="1381263117297" MODIFIED="1381263361863" COLOR="#111111">
<richcontent TYPE="NODE">
<html>
  <head>
    
  </head>
  <body>
    <img src="arquitectura-redes-images/topologias.gif"/>
  </body>
</html></richcontent>
<font SIZE="12"/>
</node>
</node>
<node TEXT="m&#xe9;todo de acceso a la red" ID="ID_1482464817" CREATED="1381262982854" MODIFIED="1381262989013" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="medio es compartido" ID="ID_1599734584" CREATED="1381263404779" MODIFIED="1381263539536" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="transmisi&#xf3;n simultanea -&gt; colisi&#xf3;n" ID="ID_694454874" CREATED="1381263540862" MODIFIED="1381263553482" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="se ha ce controlar el uso del medio" ID="ID_299899880" CREATED="1381263554685" MODIFIED="1381263565109" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="medio no compartido" ID="ID_1746582937" CREATED="1381263599470" MODIFIED="1381263605179" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="acceso trivial" ID="ID_1328595072" CREATED="1381263615261" MODIFIED="1381263638387" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="no se necesita m&#xe9;todo de control del medio" ID="ID_750087630" CREATED="1381263638846" MODIFIED="1381263653019" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="protocolos de comunicaciones" ID="ID_1313171970" CREATED="1381262990863" MODIFIED="1381262997805" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="normas utilizadas en red para realizar comunicaci&#xf3;n" ID="ID_965561924" CREATED="1381263668630" MODIFIED="1381263702328" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="normas tienen en cuenta aspectos como" ID="ID_309114173" CREATED="1381263703054" MODIFIED="1381263715624" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="m&#xe9;todo para corregir errores" ID="ID_56938466" CREATED="1381263715627" MODIFIED="1381263725204" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="m&#xe9;todo para establecer comunicaci&#xf3;n" ID="ID_711022313" CREATED="1381263726175" MODIFIED="1381263739108" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="velocidad de transmisi&#xf3;n" ID="ID_1739143461" CREATED="1381263739655" MODIFIED="1381263750501" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="tipo de informaci&#xf3;n" ID="ID_1119477253" CREATED="1381263751431" MODIFIED="1381263758028" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="formato de los mensajes" ID="ID_191179569" CREATED="1381263758543" MODIFIED="1381263765124" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="etc" ID="ID_1172185281" CREATED="1381263765556" MODIFIED="1381263807998" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Arquitecturas por niveles" POSITION="right" ID="ID_981112823" CREATED="1381263874216" MODIFIED="1381466863391" COLOR="#0033ff">
<font SIZE="18"/>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<cloud WIDTH="0"/>
<node TEXT="redes se organizan en capas o niviles para reducir complejidad" ID="ID_182192164" CREATED="1381264253996" MODIFIED="1381264282549" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="dise&#xf1;o" ID="ID_253099118" CREATED="1381264282552" MODIFIED="1381264286189" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="an&#xe1;lisis" ID="ID_118281090" CREATED="1381264288895" MODIFIED="1381264292745" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="cada capa" ID="ID_297674136" CREATED="1381264305884" MODIFIED="1381264310870" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="se construye sobre su predecesor" ID="ID_263423120" CREATED="1381264310872" MODIFIED="1381465458073" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="utiliza servicios del nivel inferior" ID="ID_338583605" CREATED="1381264343173" MODIFIED="1381264509430" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="ofrece servicios a niveles superiores" ID="ID_132013946" CREATED="1381264322429" MODIFIED="1381264338730" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="cada nivel s&#xf3;lo se comunica con" ID="ID_1801528175" CREATED="1381264469809" MODIFIED="1381264481871" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="nivel superior inmediato" ID="ID_97453083" CREATED="1381264481873" MODIFIED="1381264494603" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="nivel inferior inmediato" ID="ID_401779353" CREATED="1381264495158" MODIFIED="1381264502636" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="los servicios se definen mediante protocolos" ID="ID_310243399" CREATED="1381264437958" MODIFIED="1381264455083" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="dos equipos que se comunican usando la misma arquitectura" ID="ID_344107062" CREATED="1381264553551" MODIFIED="1381264590627" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="protocolos del mismo nivel" ID="ID_1576467139" CREATED="1381264590629" MODIFIED="1381264603020" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="se coordinan en ambas m&#xe1;quinas" ID="ID_1609880955" CREATED="1381465607474" MODIFIED="1381465620926" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="usan las mismas reglas de transmisi&#xf3;n" ID="ID_1453609449" CREATED="1381465644265" MODIFIED="1381465658222" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="elementos activos en comunicaci&#xf3;n" ID="ID_702215428" CREATED="1381264603791" MODIFIED="1381465718282" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="se les llama entidades o procesos" ID="ID_278215872" CREATED="1381465718284" MODIFIED="1381465730630" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="en el mismo nivel se llaman" ID="ID_799360023" CREATED="1381465894920" MODIFIED="1381465914841" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="entidades o procesos pares" ID="ID_171331636" CREATED="1381465914843" MODIFIED="1381465921309" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Encapsulamiento de los datos" POSITION="right" ID="ID_1068136473" CREATED="1381465738488" MODIFIED="1381466866699" COLOR="#0033ff">
<font SIZE="18"/>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<cloud WIDTH="0"/>
<node TEXT="en cada nivel se necesita" ID="ID_851134702" CREATED="1381465770764" MODIFIED="1381465807337" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="informaci&#xf3;n adicional" ID="ID_1909376238" CREATED="1381465807339" MODIFIED="1381466033318" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="permite coordinaci&#xf3;n en entidades o procesos pares" ID="ID_950495716" CREATED="1381465928608" MODIFIED="1381465960836" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="se le llama" ID="ID_914247659" CREATED="1381465979552" MODIFIED="1381465988353" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="cabecera o" ID="ID_1371318322" CREATED="1381465988356" MODIFIED="1381465992405" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="informaci&#xf3;n de control" ID="ID_817707312" CREATED="1381465992920" MODIFIED="1381466003757" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="datos a transmitir" ID="ID_286802818" CREATED="1381465816456" MODIFIED="1381465821589" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="PDU" ID="ID_980857206" CREATED="1381466072968" MODIFIED="1381466076173" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="Protocol Data Unit" ID="ID_213383840" CREATED="1381466077360" MODIFIED="1381466085245" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="incluye" ID="ID_197776112" CREATED="1381466118616" MODIFIED="1381466176680" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="cabecera +  datos" ID="ID_767838830" CREATED="1381466176681" MODIFIED="1381466189373" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="usados en una capa" ID="ID_1553237558" CREATED="1381466189999" MODIFIED="1381466217685" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="recibe un nombre distinto en cada capa" ID="ID_933438170" CREATED="1381466229055" MODIFIED="1381466255477" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="nombres en arquitectura TCP/IP" ID="ID_1323440660" CREATED="1381466312999" MODIFIED="1381466325416" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="datos" ID="ID_1285912563" CREATED="1381466325418" MODIFIED="1381466330341" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="nombre PDU capa de aplicaci&#xf3;n" ID="ID_168799177" CREATED="1381466348527" MODIFIED="1381466361725" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="segmento" ID="ID_1093646177" CREATED="1381466331183" MODIFIED="1381466333596" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="nombre PDU caoa de transporte" ID="ID_1637107856" CREATED="1381466365159" MODIFIED="1381466379389" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="paquete" ID="ID_358879708" CREATED="1381466334023" MODIFIED="1381466337372" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="nombre PDU capa de interred" ID="ID_72882750" CREATED="1381466381343" MODIFIED="1381466417916" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="trama" ID="ID_1682147703" CREATED="1381466337911" MODIFIED="1381466339700" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="nombre PDU capa de enlace" ID="ID_520763176" CREATED="1381466399399" MODIFIED="1381466411733" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="bits" ID="ID_1622682047" CREATED="1381466340231" MODIFIED="1381466342076" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="nombre PDU capa f&#xed;sica" ID="ID_1403495570" CREATED="1381466420775" MODIFIED="1381466446613" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="proceso de encapsulamiento" ID="ID_173756872" CREATED="1381466471775" MODIFIED="1381466502136" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="se produce durante la comunicaci&#xf3;n" ID="ID_380880067" CREATED="1381466502139" MODIFIED="1381466517261" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="capa recibe PDU de la capa superio" ID="ID_1767333042" CREATED="1381466518031" MODIFIED="1381466534781" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="lo convierte en datos de su capa" ID="ID_987225379" CREATED="1381466536175" MODIFIED="1381466562357" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="Le a&#xf1;ade encabezado (informaci&#xf3;n de control)" ID="ID_379181058" CREATED="1381466562927" MODIFIED="1381466585284" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="Se obtiene PDU de la capa actual" ID="ID_1818933274" CREATED="1381466595671" MODIFIED="1381466606580" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="Proceso se repite sucesivamente hasta capa inferior" ID="ID_1641194552" CREATED="1381466634511" MODIFIED="1381466647116" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="Proceso inverso en el receptor" ID="ID_1841228738" CREATED="1381466647975" MODIFIED="1381466657501" COLOR="#111111">
<font SIZE="12"/>
</node>
<node ID="ID_928802920" CREATED="1381466660071" MODIFIED="1381466708587" COLOR="#111111">
<richcontent TYPE="NODE">
<html>
  <head>
    
  </head>
  <body>
    <img src="arquitectura-redes-images/encapsulamiento.jpg"/>
  </body>
</html></richcontent>
<font SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="Modelo de referencia OSI" POSITION="left" ID="ID_50136140" CREATED="1381466873552" MODIFIED="1381466883277" COLOR="#0033ff">
<font SIZE="18"/>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<node TEXT="Carater&#xed;sticas" ID="ID_286174740" CREATED="1381466970808" MODIFIED="1381467035725" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="Interconexi&#xf3;n Sistemas Abiertos" ID="ID_1474694916" CREATED="1381467037072" MODIFIED="1381467053853" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="Propuesta de la ISO (Organizaci&#xf3;n Internacional de Normas)" ID="ID_1615709891" CREATED="1381467054456" MODIFIED="1381467096652" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="pretende normalizaci&#xf3;n mundial de protocolos de comunicaci&#xf3;n" ID="ID_454453365" CREATED="1381467103944" MODIFIED="1381467536919" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="pensado para interconexi&#xf3;n de sistemas diferentes" ID="ID_1157378533" CREATED="1381467147273" MODIFIED="1381467182574" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="principios de su dise&#xf1;o" ID="ID_1991739124" CREATED="1381467232577" MODIFIED="1381467240414" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="cada capa realiza funci&#xf3;n bien definida" ID="ID_1271958312" CREATED="1381467241953" MODIFIED="1381467256542" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="n&#xfa;mero de niveles" ID="ID_463678095" CREATED="1381467257233" MODIFIED="1381467274946" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="suficiente para que no se agrupen funciones distintas" ID="ID_485046698" CREATED="1381467274948" MODIFIED="1381467295166" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="no tan grande que lo haga inmanejable" ID="ID_1594835346" CREATED="1381467295993" MODIFIED="1381467305286" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="se crea capa si hay que diferenciar funci&#xf3;n del resto" ID="ID_748497692" CREATED="1381467306937" MODIFIED="1381467332590" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="divisi&#xf3;n de capas debe minimizar flujo de informaci&#xf3;n entre capas" ID="ID_1493421265" CREATED="1381467333305" MODIFIED="1381467369727" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="modificaci&#xf3;nes en una capa no deben afectar capas contiguas" ID="ID_1190458466" CREATED="1381467377698" MODIFIED="1381467399287" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="partir de experiencia con protocolos existentes" ID="ID_1987199250" CREATED="1381467409938" MODIFIED="1381467428231" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="cada nivel s&#xf3;lo interacciona con niveles contiguos" ID="ID_80902291" CREATED="1381467430602" MODIFIED="1381467444311" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="funci&#xf3;n de cada capa basada en protocolos estandarizados" ID="ID_140232562" CREATED="1381467454274" MODIFIED="1381467486255" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="pensado como modelo" ID="ID_241459323" CREATED="1381467023656" MODIFIED="1381467527239" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="ISO define su funci&#xf3;n general" ID="ID_1775467029" CREATED="1381467543250" MODIFIED="1381467553807" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="no se definen" ID="ID_958911816" CREATED="1381467554322" MODIFIED="1381467566227" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="servicios" ID="ID_287315181" CREATED="1381467566229" MODIFIED="1381467570167" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="protocolos" ID="ID_235838640" CREATED="1381467570618" MODIFIED="1381467573735" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="usado como referencia" ID="ID_1500531749" CREATED="1381467616507" MODIFIED="1381467623455" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="no existen arquiecturas de redes reales que lo usen" ID="ID_438735926" CREATED="1381467625378" MODIFIED="1381467642488" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="algunos aspectos mal dise&#xf1;ados" ID="ID_945929126" CREATED="1381467744539" MODIFIED="1381468376528" COLOR="#990000">
<font SIZE="14" BOLD="true"/>
<node TEXT="algunas capas vacias" ID="ID_1822121939" CREATED="1381467758851" MODIFIED="1381467774960" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="algunas capas sobrecargadas de funciones" ID="ID_83549242" CREATED="1381467775443" MODIFIED="1381467784392" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="funciones repetidas en capas diferentes" ID="ID_1472342870" CREATED="1381467794075" MODIFIED="1381467823128" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="funciones por nivel" ID="ID_253616115" CREATED="1381467658443" MODIFIED="1381467664408" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="f&#xed;sico" ID="ID_32383464" CREATED="1381467666042" MODIFIED="1381467671480" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="encargado de" ID="ID_1534316289" CREATED="1381467831205" MODIFIED="1381467877672" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="transmisi&#xf3;n binaria por canal de comunicaci&#xf3;n" ID="ID_1038856280" CREATED="1381467880405" MODIFIED="1381467893800" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="par&#xe1;metros t&#xed;picos" ID="ID_1572661749" CREATED="1381467913004" MODIFIED="1381467919993" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="voltajes" ID="ID_686852471" CREATED="1381467922844" MODIFIED="1381467926216" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="frecuencias" ID="ID_176206158" CREATED="1381467926931" MODIFIED="1381467935601" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="conectores" ID="ID_1512408429" CREATED="1381467936187" MODIFIED="1381467955217" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="aspectos del dise&#xf1;o" ID="ID_732197982" CREATED="1381467980036" MODIFIED="1381467987169" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="el&#xe9;ctricos" ID="ID_1313778948" CREATED="1381467988764" MODIFIED="1381467993017" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="mec&#xe1;nicos" ID="ID_1357092920" CREATED="1381467993588" MODIFIED="1381467998489" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="medio f&#xed;sico de transmisi&#xf3;n" ID="ID_687873618" CREATED="1381468029156" MODIFIED="1381468038345" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="cables" ID="ID_233807980" CREATED="1381468045572" MODIFIED="1381468049681" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="inal&#xe1;mbricos" ID="ID_1872142771" CREATED="1381468052484" MODIFIED="1381468057961" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="etc" ID="ID_788611388" CREATED="1381468058572" MODIFIED="1381468060433" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="enlace de datos" ID="ID_1069467681" CREATED="1381467672954" MODIFIED="1381467676608" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="funciones" ID="ID_1096557428" CREATED="1381468072900" MODIFIED="1381468553491" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="detectar/corregir errores en l&#xed;nea de comunicaci&#xf3;n" ID="ID_1070368120" CREATED="1381468081356" MODIFIED="1381468102465" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="evitar saturaciones" ID="ID_324514353" CREATED="1381468121644" MODIFIED="1381468151465" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="repartir uso del medio en caso de que sea compartido" ID="ID_1564348713" CREATED="1381468152564" MODIFIED="1381468171793" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="PDU" ID="ID_752385280" CREATED="1381468177980" MODIFIED="1381468180809" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="trama o marco" ID="ID_601455648" CREATED="1381468182244" MODIFIED="1381468191536" COLOR="#111111">
<font SIZE="12" BOLD="true"/>
</node>
</node>
</node>
<node TEXT="red" ID="ID_1625745269" CREATED="1381467677091" MODIFIED="1381467679671" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="funciones" ID="ID_380862786" CREATED="1381468198702" MODIFIED="1381468541539" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="determinar mejor ruta para envio de informaci&#xf3;n" ID="ID_27293987" CREATED="1381468206940" MODIFIED="1381468222049" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="m&#xe1;s corto" ID="ID_1085781849" CREATED="1381468227860" MODIFIED="1381468276481" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="m&#xe1;s r&#xe1;pido" ID="ID_1897331486" CREATED="1381468252268" MODIFIED="1381468265234" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="menor tr&#xe1;fico" ID="ID_1449616006" CREATED="1381468265836" MODIFIED="1381468269986" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="controlar congesti&#xf3;n de la red" ID="ID_1733011714" CREATED="1381468283044" MODIFIED="1381468290954" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="repartir carga entre diferentes rutas" ID="ID_838404274" CREATED="1381468304165" MODIFIED="1381468316009" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="convertir mensajes al circular por redes heterogeneas" ID="ID_1997531139" CREATED="1381468323997" MODIFIED="1381468352602" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="PDU" ID="ID_1476312947" CREATED="1381468358717" MODIFIED="1381468361890" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="paquete" ID="ID_240148326" CREATED="1381468362909" MODIFIED="1381468380416" COLOR="#111111">
<font SIZE="12" BOLD="true"/>
</node>
</node>
</node>
<node TEXT="transporte" ID="ID_1290625707" CREATED="1381467681123" MODIFIED="1381467684168" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="funciones" ID="ID_1720655086" CREATED="1381468383125" MODIFIED="1381468576798" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="obtener datos capa de sesi&#xf3;n y pasarlos a la de red" ID="ID_763743043" CREATED="1381468394109" MODIFIED="1381468407562" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="asegurarse datos llegan correctamente al otro extremo de la cuomunicaci&#xf3;n" ID="ID_712196232" CREATED="1381468423037" MODIFIED="1381468441083" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="extremo a extremo" ID="ID_1537332366" CREATED="1381468465430" MODIFIED="1381468480867" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="no hay comunicaci&#xf3;n con capas de transporte intermedias" ID="ID_149138687" CREATED="1381468482461" MODIFIED="1381468496451" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="sesi&#xf3;n" ID="ID_38121156" CREATED="1381467684739" MODIFIED="1381467696920" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="funciones" ID="ID_1971185962" CREATED="1381468524365" MODIFIED="1381468529739" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="gesti&#xf3;n de sesiones de comunicaci&#xf3;n" ID="ID_1439324906" CREATED="1381468591510" MODIFIED="1381468658908" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="estrablecimiento" ID="ID_624317040" CREATED="1381468625462" MODIFIED="1381468629355" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="mantenimiento" ID="ID_1460891615" CREATED="1381468629758" MODIFIED="1381468634571" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="finalizaci&#xf3;n" ID="ID_1447276061" CREATED="1381468635446" MODIFIED="1381468639275" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="proporciona servicios mejorados" ID="ID_1857466097" CREATED="1381468701767" MODIFIED="1381468710195" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="reanudaci&#xf3;n de comunicaci&#xf3;n por" ID="ID_1052070471" CREATED="1381468711366" MODIFIED="1381468732804" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="fallo en la red" ID="ID_1226469155" CREATED="1381468733846" MODIFIED="1381468737339" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="interrupci&#xf3;n" ID="ID_431042378" CREATED="1381468737950" MODIFIED="1381468751260" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="presentaci&#xf3;n" ID="ID_1680842403" CREATED="1381467697507" MODIFIED="1381467701992" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="funciones" ID="ID_1739987144" CREATED="1381468763495" MODIFIED="1381468766524" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="controlar significado de informaci&#xf3;n transmitida" ID="ID_698779904" CREATED="1381468768591" MODIFIED="1381468803548" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="traducci&#xf3;n entre diferentes tipos de estaciones" ID="ID_110144180" CREATED="1381468822695" MODIFIED="1381468841347" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="codificaci&#xf3;n y cifrado de datos" ID="ID_281687158" CREATED="1381468841919" MODIFIED="1381468851868" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="aplicaci&#xf3;n" ID="ID_1886479811" CREATED="1381467702458" MODIFIED="1381467706384" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="funciones" ID="ID_531350659" CREATED="1381468871071" MODIFIED="1381468874131" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="contacto directo con programas/aplicaciones" ID="ID_89030029" CREATED="1381468876599" MODIFIED="1381468897172" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="contiene" ID="ID_1363628189" CREATED="1381468926623" MODIFIED="1381468936491" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="servicios de comunicaci&#xf3;n m&#xe1;s utilizados" ID="ID_666066453" CREATED="1381468937639" MODIFIED="1381468950532" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="transferencia de archivos" ID="ID_1629797988" CREATED="1381468952959" MODIFIED="1381468963076" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="correo electr&#xf3;nico" ID="ID_1515865539" CREATED="1381468963575" MODIFIED="1381468968732" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="web" ID="ID_107847355" CREATED="1381468981831" MODIFIED="1381468983300" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="etc" ID="ID_1676192542" CREATED="1381468994503" MODIFIED="1381468997444" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
</node>
</node>
<node TEXT="Arquitectura TCP/IP" POSITION="left" ID="ID_1890180171" CREATED="1381466891336" MODIFIED="1381466908461" COLOR="#0033ff">
<font SIZE="18"/>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<node TEXT="caracter&#xed;sticas" ID="ID_1478812202" CREATED="1381469020263" MODIFIED="1381469052437" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="familia de protocolos apilados por capas" ID="ID_1413796912" CREATED="1381469054071" MODIFIED="1381469063941" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="arquitectura m&#xe1;s utilizada en el mundo" ID="ID_1005910565" CREATED="1381469068472" MODIFIED="1381469079957" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="base de comunicciones de Internet" ID="ID_443608403" CREATED="1381469080568" MODIFIED="1381469093781" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="dise&#xf1;ada por DoD de EEUU en 1973" ID="ID_1353072136" CREATED="1381469109856" MODIFIED="1381469127036" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="principios de dise&#xf1;o" ID="ID_1670481193" CREATED="1381469128848" MODIFIED="1381469136581" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="interconexi&#xf3;n de redes diferentes" ID="ID_527300714" CREATED="1381469139272" MODIFIED="1381469151397" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="red incluye tramos con diferentes tecnolog&#xed;as" ID="ID_790890076" CREATED="1381469156752" MODIFIED="1381469167973" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="tolerante a fallos" ID="ID_576615095" CREATED="1381469170056" MODIFIED="1381469179421" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="pensada para soportar ataques" ID="ID_566112879" CREATED="1381469182368" MODIFIED="1381469188925" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="uso de aplicaciones diferentes" ID="ID_243104496" CREATED="1381469193064" MODIFIED="1381469201725" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="transferencia de archivos" ID="ID_1870240896" CREATED="1381469202784" MODIFIED="1381469209917" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="tiempo real" ID="ID_819631997" CREATED="1381469210560" MODIFIED="1381469218933" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="consecuencias" ID="ID_1856298619" CREATED="1381469272880" MODIFIED="1381469276884" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="topolog&#xed;a irregular" ID="ID_1431052543" CREATED="1381469278352" MODIFIED="1381469289301" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="informaci&#xf3;n viaja fragmentada" ID="ID_1575789136" CREATED="1381469290376" MODIFIED="1381469299797" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="fragmentos siguen rutas diferentes" ID="ID_1703243889" CREATED="1381469300512" MODIFIED="1381469314213" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="existencia de rutas alternativas" ID="ID_1669750990" CREATED="1381469318600" MODIFIED="1381469326333" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Historia" ID="ID_788773800" CREATED="1381469389873" MODIFIED="1381469573847" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="inicialmente" ID="ID_649935137" CREATED="1381469578897" MODIFIED="1381469583837" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="ARPANET" ID="ID_359423380" CREATED="1381469398640" MODIFIED="1381469588293" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="red para investigaci&#xf3;n" ID="ID_1251964589" CREATED="1381469416496" MODIFIED="1381469427022" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="colaboraron universidades" ID="ID_82982280" CREATED="1381469431265" MODIFIED="1381469447685" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="arquitectura de red usada nombrada como TCP/IP" ID="ID_1669409399" CREATED="1381469481385" MODIFIED="1381469789927" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="iniciales de los dos protocolos m&#xe1;s importantes" ID="ID_1447940269" CREATED="1381469517081" MODIFIED="1381469526894" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="MILNET" ID="ID_285146732" CREATED="1381469406674" MODIFIED="1381469591098" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="red militar" ID="ID_247038575" CREATED="1381469411208" MODIFIED="1381469414341" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="1980" ID="ID_217059341" CREATED="1381469628137" MODIFIED="1381469636134" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="TCP/IP es incluido en UNIX" ID="ID_825221818" CREATED="1381469638721" MODIFIED="1381469649006" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="1983" ID="ID_366516209" CREATED="1381469696761" MODIFIED="1381469700326" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="TCP/IP protocolo militar est&#xe1;ndar" ID="ID_1547284310" CREATED="1381469701849" MODIFIED="1381469720398" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="Nace Internet que usa TCP/IP" ID="ID_4191088" CREATED="1381469721545" MODIFIED="1381469733629" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="1990" ID="ID_1466941890" CREATED="1381469741873" MODIFIED="1381469745855" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="deja de funcionar ARPANET" ID="ID_1241851012" CREATED="1381469747937" MODIFIED="1381469769318" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="Motivos popularidad" ID="ID_650547231" CREATED="1381469806714" MODIFIED="1381469818095" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="independiente de" ID="ID_1954852496" CREATED="1381469824810" MODIFIED="1381469833414" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="fabricantes" ID="ID_1931202854" CREATED="1381469834802" MODIFIED="1381469838263" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="marcas comerciales" ID="ID_1676334562" CREATED="1381469838706" MODIFIED="1381469843263" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="soporta m&#xfa;ltiples tecnolog&#xed;as de redes" ID="ID_1133211110" CREATED="1381469847474" MODIFIED="1381469860623" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="permite interconectar redes de diferentes tecnolog&#xed;as" ID="ID_1628506510" CREATED="1381469863818" MODIFIED="1381469882279" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="funciona en m&#xe1;quinas de cualquier tama&#xf1;o" ID="ID_124124648" CREATED="1381469889178" MODIFIED="1381469901800" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="est&#xe1;ndar de comunicaciones en EEUU desde 1983" ID="ID_1166456951" CREATED="1381469907450" MODIFIED="1381469918584" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="Relaci&#xf3;n TCP/IP - OSI" ID="ID_880887516" CREATED="1381469947851" MODIFIED="1381469956496" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node ID="ID_1518933776" CREATED="1381469988515" MODIFIED="1381469997459" COLOR="#990000">
<richcontent TYPE="NODE">
<html>
  <head>
    
  </head>
  <body>
    <img src="arquitectura-redes-images/tcpip_osi.jpg"/>
  </body>
</html></richcontent>
<font SIZE="14"/>
</node>
</node>
<node TEXT="5 capas" ID="ID_1824993524" CREATED="1381470020523" MODIFIED="1381470025784" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="enlace de datos" ID="ID_131252473" CREATED="1381470027323" MODIFIED="1381470033576" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="no se detalla en el modelo" ID="ID_983672395" CREATED="1381470034707" MODIFIED="1381470048520" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="s&#xf3;lo se especifica que" ID="ID_1148915762" CREATED="1381470064068" MODIFIED="1381470074369" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="debe existir protocolo que conecte estaci&#xf3;n con la red" ID="ID_1818308037" CREATED="1381470083316" MODIFIED="1381725970628" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="depende de la tecnolog&#xed;a utilizada" ID="ID_1255088993" CREATED="1381470113812" MODIFIED="1381470129705" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="diferentes tipos de cables" ID="ID_1156600013" CREATED="1381726001020" MODIFIED="1381726029009" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="inal&#xe1;mbricas" ID="ID_166313310" CREATED="1381726029579" MODIFIED="1381726035760" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="diferentes se&#xf1;ales" ID="ID_1361974713" CREATED="1381726036459" MODIFIED="1381726044128" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="internet" ID="ID_1216170247" CREATED="1381470165764" MODIFIED="1381470170553" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="capa m&#xe1;s importante de la arquitectura" ID="ID_1750713611" CREATED="1381470177732" MODIFIED="1381470186361" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="PDU" ID="ID_1104099526" CREATED="1381470298109" MODIFIED="1381470301582" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="paquete" ID="ID_196716230" CREATED="1381470301584" MODIFIED="1381470307064" COLOR="#111111">
<font SIZE="12" BOLD="true"/>
</node>
</node>
<node TEXT="funci&#xf3;n" ID="ID_1962178855" CREATED="1381470187092" MODIFIED="1381470190088" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="permitir que paquetes viajen de forma independiente a su destino" ID="ID_643817351" CREATED="1381470190636" MODIFIED="1381470223666" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="caracter&#xed;sticas" ID="ID_1188779779" CREATED="1381470238508" MODIFIED="1381470247298" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="paquetes atraviesan redes diferentes" ID="ID_1771654103" CREATED="1381470252693" MODIFIED="1381470261522" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="paquetes pueden llegar desordenados" ID="ID_925805079" CREATED="1381470262149" MODIFIED="1381470276762" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="no se encarga de reordenar" ID="ID_547896665" CREATED="1381470277445" MODIFIED="1381470286594" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="Protocolo m&#xe1;s importante" ID="ID_1294963383" CREATED="1381470310877" MODIFIED="1381470375075" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="IP(Internet Protocol o Protocolo de Interred)" ID="ID_1289062751" CREATED="1381470323077" MODIFIED="1381470360330" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="transporte" ID="ID_1278898108" CREATED="1381470379589" MODIFIED="1381470383698" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="funci&#xf3;n" ID="ID_1530285294" CREATED="1381470388158" MODIFIED="1381470391098" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="establecer conversaci&#xf3;n entre" ID="ID_1049561879" CREATED="1381470392661" MODIFIED="1381470402294" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="orien" ID="ID_48891539" CREATED="1381470402296" MODIFIED="1381470404834" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="destino" ID="ID_24525594" CREATED="1381470405261" MODIFIED="1381470408019" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="control de errores" ID="ID_1859639248" CREATED="1381470425582" MODIFIED="1381470431131" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="reordenaci&#xf3;n de mensajes" ID="ID_1780325467" CREATED="1381470431717" MODIFIED="1381470437506" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="protocolos m&#xe1;s importantes" ID="ID_373211640" CREATED="1381470443870" MODIFIED="1381470458203" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="TCP(Protocolo de Control de la Transmisi&#xf3;n)" ID="ID_1871027309" CREATED="1381470459245" MODIFIED="1381470491803" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="UDP(Protocolo de Datagrama de Usuario)" ID="ID_1153011212" CREATED="1381470492374" MODIFIED="1381470512771" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="aplicaci&#xf3;n" ID="ID_1152565741" CREATED="1381470518478" MODIFIED="1381470541009" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="contiene" ID="ID_928365993" CREATED="1381726139923" MODIFIED="1381726143988" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="protocolos de alto nivel que utilizan programas para comunicarse" ID="ID_867260267" CREATED="1381726143991" MODIFIED="1381726172464" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="ejemplos protocolos" ID="ID_558935874" CREATED="1381726225787" MODIFIED="1381726233135" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="TELNET" ID="ID_1182816244" CREATED="1381726235131" MODIFIED="1381726241201" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="FTP" ID="ID_884470505" CREATED="1381726241755" MODIFIED="1381726245793" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="HTTP" ID="ID_451471882" CREATED="1381726246483" MODIFIED="1381726252752" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="gesti&#xf3;n de correo" ID="ID_599248995" CREATED="1381726256403" MODIFIED="1381726262487" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="SSH" ID="ID_1541174466" CREATED="1381726262915" MODIFIED="1381726264951" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="no se incluyen las capas OSI de" ID="ID_154969799" CREATED="1381726297507" MODIFIED="1381726343209" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="presentaci&#xf3;n" ID="ID_934949467" CREATED="1381726314403" MODIFIED="1381726319361" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="sesi&#xf3;n" ID="ID_131045625" CREATED="1381726319859" MODIFIED="1381726324505" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
</node>
<node TEXT="Arquitectura de redes locales" POSITION="left" ID="ID_1559153027" CREATED="1381466917600" MODIFIED="1381466925629" COLOR="#0033ff">
<font SIZE="18"/>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<node TEXT="existen" ID="ID_1871185385" CREATED="1381726376867" MODIFIED="1381726385525" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="multitud est&#xe1;ndares y protocolos de redes locales" ID="ID_996793681" CREATED="1381726385527" MODIFIED="1381726407905" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="cada tecnolog&#xed;a de red local utiliza diferentes protocolos en los niveles" ID="ID_76790184" CREATED="1381726410075" MODIFIED="1381726448204" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="f&#xed;sico" ID="ID_1479593719" CREATED="1381726448212" MODIFIED="1381726451129" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="incluye elementos relacionados hardware" ID="ID_717617706" CREATED="1381726665132" MODIFIED="1381726684009" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="tarjetas de red" ID="ID_1253001587" CREATED="1381726684908" MODIFIED="1381726691409" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="cables" ID="ID_401532138" CREATED="1381726692051" MODIFIED="1381726702081" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="se&#xf1;ales electromagn&#xe9;ticas" ID="ID_842827999" CREATED="1381726702491" MODIFIED="1381726710465" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="etc" ID="ID_320680120" CREATED="1381726711052" MODIFIED="1381726712609" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="enlace de datos" ID="ID_1028082251" CREATED="1381726451643" MODIFIED="1381726462377" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="proporciona" ID="ID_268329393" CREATED="1381726727684" MODIFIED="1381726733677" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="fiabilidad en intercambio de tramas entre estaciones" ID="ID_1765563539" CREATED="1381726733679" MODIFIED="1381726749881" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="control" ID="ID_1701943683" CREATED="1381726755796" MODIFIED="1381726762725" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="errores" ID="ID_1799245513" CREATED="1381726762727" MODIFIED="1381726765321" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="flujo" ID="ID_1350253975" CREATED="1381726765764" MODIFIED="1381726769457" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="uso de medio compartido" ID="ID_1378232827" CREATED="1381726784644" MODIFIED="1381726797696" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="se establecen mecanismos para control de acceso al medio" ID="ID_1399960872" CREATED="1381726804908" MODIFIED="1381726819633" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="en los niveles superiores se la arquitectura" ID="ID_1993570929" CREATED="1381726477132" MODIFIED="1381726521101" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="TCP/IP" ID="ID_700648721" CREATED="1381726521103" MODIFIED="1381726542432" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="ejemplos" ID="ID_46060929" CREATED="1381726543771" MODIFIED="1381726567157" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="Ethernet" ID="ID_1934731333" CREATED="1381726567159" MODIFIED="1381726576209" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="Token Ring" ID="ID_1972455272" CREATED="1381726577268" MODIFIED="1381726582601" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="FDDI" ID="ID_1543848850" CREATED="1381726583172" MODIFIED="1381726587801" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="wi-fi" ID="ID_1705334750" CREATED="1381726588388" MODIFIED="1381726592945" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="concepto de colisi&#xf3;n" ID="ID_783772917" CREATED="1381726864652" MODIFIED="1381726871137" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="mezcla de tramas" ID="ID_360424883" CREATED="1381726874028" MODIFIED="1381726897881" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="se produce cuando dos estaciones" ID="ID_550744429" CREATED="1381726905132" MODIFIED="1381726923685" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="transmiten de forma simultanea" ID="ID_1991642840" CREATED="1381726923687" MODIFIED="1381726933545" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="en el mismo medio" ID="ID_1250195832" CREATED="1381726934044" MODIFIED="1381726938481" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="se necesitan mecanismos" ID="ID_527617987" CREATED="1381726947420" MODIFIED="1381726964429" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="control acceso al medio" ID="ID_1835697004" CREATED="1381726964431" MODIFIED="1381726971937" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="relaci&#xf3;n entre niveles arquitecturas" ID="ID_1338734590" CREATED="1381726991892" MODIFIED="1381727016393" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node ID="ID_1719691687" CREATED="1381727017644" MODIFIED="1381727079140" COLOR="#990000">
<richcontent TYPE="NODE">
<html>
  <head>
    
  </head>
  <body>
    <img src="arquitectura-redes-images/arquitecturalan-osi-tcpip.jpg"/>
  </body>
</html>
</richcontent>
<font SIZE="14"/>
</node>
</node>
</node>
<node TEXT="Ethernet" POSITION="left" ID="ID_1713122882" CREATED="1381727116684" MODIFIED="1381727121025" COLOR="#0033ff">
<font SIZE="18"/>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<node TEXT="es un" ID="ID_1486481772" CREATED="1381727129316" MODIFIED="1381727136645" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="est&#xe1;ndar de redes de &#xe1;rea local" ID="ID_1055783890" CREATED="1381727136647" MODIFIED="1381727147209" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="define" ID="ID_944600555" CREATED="1381727153468" MODIFIED="1381727158333" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="a nivel f&#xed;sico" ID="ID_268620314" CREATED="1381727158335" MODIFIED="1381727172393" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="cableado" ID="ID_1402901194" CREATED="1381727173612" MODIFIED="1381728490483" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="se&#xf1;alizaci&#xf3;n" ID="ID_522697016" CREATED="1381728491022" MODIFIED="1381728496355" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="a nivel de enlace" ID="ID_1848695712" CREATED="1381727180860" MODIFIED="1381728651809" COLOR="#990000">
<font SIZE="14"/>
<cloud WIDTH="0"/>
<node TEXT="formato tramas de datos" ID="ID_1960236894" CREATED="1381727187772" MODIFIED="1381727204641" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="incluye dos subniveles" ID="ID_1172073827" CREATED="1381727263684" MODIFIED="1381727272057" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="MAC" ID="ID_589465699" CREATED="1381727273364" MODIFIED="1381727278306" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="Medium Acces Control" ID="ID_1737513491" CREATED="1381727332057" MODIFIED="1381727341578" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="nivel mas bajo" ID="ID_422424447" CREATED="1381727288828" MODIFIED="1381727293992" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="se encarga del control de acceso al medio" ID="ID_1996943753" CREATED="1381727294660" MODIFIED="1381727314169" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="LLC" ID="ID_194341366" CREATED="1381727279436" MODIFIED="1381727281434" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="Logical Link Control" ID="ID_1205374784" CREATED="1381727348428" MODIFIED="1381727359218" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="nivel m&#xe1;s alto" ID="ID_1474480257" CREATED="1381727431452" MODIFIED="1381727437946" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="se encarga de servicios t&#xed;picos capa enlace" ID="ID_1140105473" CREATED="1381727360324" MODIFIED="1381727391681" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="control errores" ID="ID_1105361062" CREATED="1381727392684" MODIFIED="1381727418785" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="control flujo" ID="ID_259229229" CREATED="1381727419356" MODIFIED="1381727424922" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
</node>
<node TEXT="detalles que TCP/IP deja sin especificar" ID="ID_406251355" CREATED="1381727218188" MODIFIED="1381727236025" COLOR="#990000">
<font SIZE="14"/>
</node>
</node>
<node TEXT="historia" ID="ID_902455413" CREATED="1381727465444" MODIFIED="1381727468889" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<node TEXT="dise&#xf1;ado en 1976 por fabricante Xerox" ID="ID_784627169" CREATED="1381727473076" MODIFIED="1381728610109" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="revisado posteriormente por fabricantes" ID="ID_1563032603" CREATED="1381727486716" MODIFIED="1381727502449" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="Intel" ID="ID_1970772078" CREATED="1381727506246" MODIFIED="1381727510874" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="DEC" ID="ID_416086193" CREATED="1381727511412" MODIFIED="1381727513665" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="Xerox" ID="ID_240537449" CREATED="1381727514164" MODIFIED="1381727516545" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="permit&#xed;a velocidades de hasta 10 Mbps" ID="ID_1910334898" CREATED="1381727520476" MODIFIED="1381728618603" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="M&#xe1;s adelante" ID="ID_231045" CREATED="1381727551596" MODIFIED="1381727588102" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="organizaci&#xf3;n IEEE" ID="ID_1560159273" CREATED="1381727588104" MODIFIED="1381727599326" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="define y amplia est&#xe1;ndar" ID="ID_1306542689" CREATED="1381727599328" MODIFIED="1381727613945" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="especificaci&#xf3;n IEEE 802" ID="ID_31616469" CREATED="1381727617773" MODIFIED="1381727630625" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
<node TEXT="dentro del est&#xe1;ndar" ID="ID_1356437849" CREATED="1381727656221" MODIFIED="1381728423993" COLOR="#00b439">
<font SIZE="16"/>
<edge STYLE="bezier" WIDTH="thin"/>
<cloud WIDTH="0"/>
<node TEXT="se definen varios tipos de redes locales" ID="ID_1292786536" CREATED="1381727696464" MODIFIED="1381727709714" COLOR="#990000">
<font SIZE="14"/>
</node>
<node TEXT="en funci&#xf3;n de" ID="ID_471502646" CREATED="1381727716045" MODIFIED="1381727720154" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="cableado utilizado" ID="ID_773350034" CREATED="1381727724573" MODIFIED="1381727729186" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="par trenzado" ID="ID_726035547" CREATED="1381727730589" MODIFIED="1381727735217" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="coaxial" ID="ID_100150724" CREATED="1381727735772" MODIFIED="1381727738586" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="fibra &#xf3;ptica" ID="ID_1787088189" CREATED="1381727740253" MODIFIED="1381727745874" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="inal&#xe1;mbricos(sin cables)" ID="ID_902651436" CREATED="1381727830509" MODIFIED="1381727845898" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="velocidad de transmisi&#xf3;n" ID="ID_191911006" CREATED="1381727751965" MODIFIED="1381727758418" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="2Mbps" ID="ID_1793832856" CREATED="1381727759364" MODIFIED="1381727768282" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="10Mbps" ID="ID_332698410" CREATED="1381727768996" MODIFIED="1381727774810" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="..." ID="ID_88987905" CREATED="1381727775404" MODIFIED="1381727777426" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="10Gbps" ID="ID_1919335956" CREATED="1381727777885" MODIFIED="1381727783682" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="formato bloques de informaci&#xf3;n enviados" ID="ID_1375853979" CREATED="1381727789956" MODIFIED="1381727806506" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="forma de compartir el medio" ID="ID_1056326771" CREATED="1381727857413" MODIFIED="1381727869258" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="especificaciones en que est&#xe1; dividido IEEE 802" ID="ID_138176070" CREATED="1381727898589" MODIFIED="1381727917586" COLOR="#990000">
<font SIZE="14"/>
<node TEXT="IEEE 802.1" ID="ID_884790785" CREATED="1381727920607" MODIFIED="1381727927322" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="define interfaz con niveles superiores" ID="ID_949247631" CREATED="1381727937397" MODIFIED="1381727966482" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="IEEE 802.2" ID="ID_1484855181" CREATED="1381727979565" MODIFIED="1381727985634" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="define subcapa LLC" ID="ID_1280511080" CREATED="1381727995901" MODIFIED="1381728013602" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="resto de especificaciones definen" ID="ID_703245304" CREATED="1381728046421" MODIFIED="1381728056474" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="subcapa MAC" ID="ID_39571800" CREATED="1381728057781" MODIFIED="1381728064282" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="nivel f&#xed;sico" ID="ID_206447491" CREATED="1381728064813" MODIFIED="1381728069730" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="IEEE 802.3" ID="ID_649579020" CREATED="1381728079085" MODIFIED="1381728099554" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="define diferentes tipos de configuraciones" ID="ID_799151844" CREATED="1381728126941" MODIFIED="1381728159778" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="incluye varias" ID="ID_483411237" CREATED="1381728160909" MODIFIED="1381728165882" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="velocidades" ID="ID_823815984" CREATED="1381728167013" MODIFIED="1381728171626" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="topolog&#xed;as" ID="ID_590558449" CREATED="1381728172717" MODIFIED="1381728176394" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="cableados" ID="ID_1139908585" CREATED="1381728176981" MODIFIED="1381728184578" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
<node TEXT="IEEE 802.5" ID="ID_320287955" CREATED="1381728189813" MODIFIED="1381728197322" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="Token Ring" ID="ID_1250359899" CREATED="1381728214181" MODIFIED="1381728229106" COLOR="#111111">
<font SIZE="12"/>
</node>
<node TEXT="Topolog&#xed;a l&#xf3;gica en anillo" ID="ID_1385815076" CREATED="1381728229677" MODIFIED="1381728241331" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="IEEE 802.11" ID="ID_379213964" CREATED="1381728249709" MODIFIED="1381728260010" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="define" ID="ID_931820779" CREATED="1381728261301" MODIFIED="1381728281003" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="redes inal&#xe1;mbricas" ID="ID_26791525" CREATED="1381728282150" MODIFIED="1381728294787" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="velocidad depende de versi&#xf3;n" ID="ID_987765602" CREATED="1381728302661" MODIFIED="1381728310411" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="IEEE 802.11b" ID="ID_1368569063" CREATED="1381728315014" MODIFIED="1381728328531" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="5,5 a 11 Mbps" ID="ID_189126233" CREATED="1381728331965" MODIFIED="1381728344947" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="IEEE 802.11g" ID="ID_1981571060" CREATED="1381728346342" MODIFIED="1381728358067" COLOR="#111111">
<font SIZE="12"/>
<node TEXT="54 Mbps" ID="ID_697469104" CREATED="1381728360678" MODIFIED="1381728366938" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
<node TEXT="etc" ID="ID_1233693913" CREATED="1381728368589" MODIFIED="1381728420992" COLOR="#111111">
<font SIZE="12"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
